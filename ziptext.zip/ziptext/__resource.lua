resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'
server_script "ziptext.net.dll"
server_export 'ZipText'
server_export 'UnZipText'
--client_script "ziptext.net.dll"
--export 'ZipText'
--export 'UnZipText'


